package org.firstinspires.ftc.teamcode.MyCode;

public class Output {
    public void Extend(int targ){

    }
    public void Retract(){

    }
    public void Score(){

    }
    public int DetectPixels(){
        return 0;
    }
}
