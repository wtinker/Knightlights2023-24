package org.firstinspires.ftc.teamcode.MyCode;

public class Intake {
    public void Start(){

    }
    public void Stop(){

    }
    public void Reverse(){

    }
    public void Extend(){

    }
}
