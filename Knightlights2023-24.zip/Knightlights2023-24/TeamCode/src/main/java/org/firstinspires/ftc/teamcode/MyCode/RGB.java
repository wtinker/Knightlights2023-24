package org.firstinspires.ftc.teamcode.MyCode;

public class RGB {
    public void SetBlue(){

    }
    public void SetRed(){

    }
    public void SetGreen(){

    }
    public void SetEndgame(int time){

    }
    public void Run(){

    }
}
